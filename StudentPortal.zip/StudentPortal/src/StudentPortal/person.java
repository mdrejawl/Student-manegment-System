package StudentPortal;
import java.util.Scanner;

public class person {
    public static Scanner input = new Scanner(System.in);
    public static String name;
    public static String id;
    public static String phone;

    public static String IDt;
    public static String IDs;
    public static String IDn;
    public static int choose;

    public static void displayinfo (){

        System.out.println("\t1. Teacher");
        System.out.println("\t2. Student");
        System.out.println("\t3. Add Your Profile\n");


    }
}
