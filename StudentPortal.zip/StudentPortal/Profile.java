package StudentPortal;


public class Profile extends person {

    public static void Profile() {
        System.out.println(" Please Choose Your Options : ");

        choose = input.nextInt();



            if (choose == 1) {
                System.out.println("\t You Choose Teacher Profile \t");
                System.out.println("\t Please enter your id: \t");
                IDt = input.next();
                switch (IDt) {
                    case "4520":
                        System.out.println("Name : Ashikur ISlam Aurnab");
                        System.out.println("Mobile: 01748208325");
                        System.out.println("Mail: ashikr.ged@diu.edu.bd");
                        System.out.println("Room No : 325");
                        break;
                    case "4525":
                        System.out.println("Name : Sajid Mahamod");
                        System.out.println("Mobile: 01777620083");
                        System.out.println("Mail: sajidmahmud430@gmail.com");
                        System.out.println("Room No : 303");
                        break;

                    case "4511":
                        System.out.println("Name : Asif Ahmed");
                        System.out.println("Mobile: 01777620082");
                        System.out.println("Mail: asifahmed@gmail.com");
                        System.out.println("Room No : 305");
                        break;

                    default:
                        System.out.println(" Not matching");
                }
            }

        else if (choose == 2) {
            System.out.println("\t You Choose Student Profile");
            System.out.println("\t Please enter your id: \t");
            IDs = input.next();
            switch (IDs){
                case "4510":
                    System.out.println("Name : Rezawl");
                    System.out.println("Date of Birth: 17-07-2000");
                    System.out.println("GPA Average : 3.00");
                    System.out.println("Session: 2020-2024");

                    break;

                case "4511":
                    System.out.println("Name : Sajid");
                    System.out.println("Date of Birth: 01-01-2001");
                    System.out.println("GPA Average : 3.50");
                    System.out.println("Session: 2020-2024");
                    break;

                default:
                    System.out.println(" Not matching");

            }

        }
        else if ( choose == 3) {
            System.out.println("\t Crate Your Profile ");
            System.out.println("Please enter your id: \t");
            id = input.next();
            System.out.println(" Enter Your Name :");
            name = input.next();
            System.out.println(" Enter Your Phone number");
            phone = input.next();
            System.out.println(" Your Name is:" +name);
            System.out.println("Your ID Is :"+id);
            System.out.println("Your Phone Number Is: " +phone);
            System.out.println("Account Update Successfully");



        }
    }

      public static void main (String[]args){
            displayinfo();
            Profile();

        }
    }

